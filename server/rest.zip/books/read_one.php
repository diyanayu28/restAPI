<?php
	// required headers
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	 
	// include database and object files
	include_once '../config/database.php';
	include_once '../objects/books.php';
	 
	// instantiate database and books object	
	$database = new Database();
	$db = $database->getConnection();
	 
	$books = new books($db);
	 
	// set ID property of books to be edited
	$books->id = isset($_GET['id']) ? $_GET['id'] : die();
	 
	// read the details of books to be edited
	$books->readOne();
	 
	// create array
	$books_arr = array(
		"id" => $books->id,
		"author_name" => $books->author_name,
		"price" => $books->price,
		"isbn" => $books->isbn,
		"category" =>  $books->category,
	 
	);
	 
	// make it json format
	print_r(json_encode($books_arr));
?>