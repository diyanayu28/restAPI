<?php
class Books{
    // database connection and table name
    private $conn;
    private $table_name = "books";
 
    // object properties
    public $id;
    public $title;
    public $author_name;
    public $price;
    public $isbn;
    public $category;
	
	// constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }
	
	// read books
	function read(){
		// select all query
		$query = "SELECT * FROM " . $this->table_name;
	 
		// prepare query statement
		$stmt = $this->conn->prepare($query);
	 
		// execute query
		$stmt->execute();
	 
		return $stmt;
	}
	
	// create books
	function create(){
		// query to insert record
		$query = "INSERT INTO ".$this->table_name." SET title=?, author_name=?, price=?,isbn=?,category=?";
	 
		// prepare query
		$stmt = $this->conn->prepare($query);
	 
        // sanitize
        $this->title = $this->title;
		$this->author_name = $this->author_name;
		$this->price = $this->price;
		$this->isbn = $this->isbn;
		$this->category = $this->category;
	 
		// bind values
        $stmt->bindParam(1, $this->title);
        $stmt->bindParam(2, $this->author_name);
		$stmt->bindParam(3, $this->price);
		$stmt->bindParam(4, $this->isbn);
		$stmt->bindParam(5, $this->category);
	 
		// execute query
		if($stmt->execute()){
			return true;
		}
		return false;
	}
	
	function readOne(){
		// query to read single record
		$query = "SELECT * FROM " . $this->table_name . " WHERE id = ? LIMIT 0,1";
		
		// prepare query statement
		$stmt = $this->conn->prepare( $query );
	 
		// bind id of books to be updated
		$stmt->bindParam(1, $this->id);
	 
		// execute query
		$stmt->execute();
	 
		// get retrieved row
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
	 
		// set values to object properties
		$this->title = $row['title'];
		$this->author_name = $row['author_name'];
		$this->price = $row['price'];
		$this->isbn = $row['isbn'];
		$this->category = $row['category'];
	}
}